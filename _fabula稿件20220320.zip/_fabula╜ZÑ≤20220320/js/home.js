; (function () {
let more_story = document.querySelector(".more-story")
let more_story_button= document.querySelector(".more-story-button")
more_story_button.addEventListener("click",()=>{
    more_story.classList.add("click")
})
})()